To run the script use the following commands: 

chmod +x run_steps.sh
./run_steps.sh <file_path>

